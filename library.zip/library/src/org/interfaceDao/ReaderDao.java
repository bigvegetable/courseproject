package org.interfaceDao;

import java.util.List;

import org.entity.Reader;


public interface ReaderDao {
	
	public int addReader(Reader reader);
	public int updateReader(Reader reader);
	public int deleteReader(int readerId);
	public Reader queryReaderById(int readerId);
	public List<Reader> queryReader();
	
}
