package org.interfaceDao;

import java.util.List;

import org.entity.Manager;

/**
 * ����Ա�����ӿ�
 * @author Administrator
 *
 */
public interface ManagerDao {
	/**
	 * ����Ա��½
	 * @param magId
	 * @param magPassword
	 * @return
	 */
	public Manager magLogin(String magName,String magPassword);
	public int updateReader(Manager manager);
	public int deleteManager(int magId);
	public List<Manager> queryManager();
	public Manager queryManagerById(int magId);
}
