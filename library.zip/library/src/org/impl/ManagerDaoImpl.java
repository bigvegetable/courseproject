package org.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.entity.Manager;

import org.interfaceDao.ManagerDao;


public class ManagerDaoImpl extends DBUtil implements ManagerDao {

	@Override
	public Manager magLogin(String magName, String magPassword) {
		Manager mag = null;	//�ڴ˴�����magΪ��
		String sql = "select magId,magName from tbl_manager where magName=? and magPassword=?";
		Object[] params = {magName,magPassword};
		try {
			rs = super.executeQuery(sql, params);
			if(rs.next()){
				mag = new Manager();
				mag.setMagId(rs.getInt(1));
				mag.setMagName(rs.getString(2));
				
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		
		return mag;
	}

	@Override
	public int deleteManager(int magId) {
		String sql = "delete tbl_Manager where magId=? ";
		Object[] params = {magId};
		return super.executeUpdate(sql, params);
	}

	@Override
	public List<Manager> queryManager() {
		List<Manager> list = new ArrayList<Manager>();
		String sql = "select * from tbl_manager";
		try {
			rs = super.executeQuery(sql, null);
			while(rs.next()){
				Manager mag = new Manager();
				mag.setMagId(rs.getInt(1));
				mag.setMagName(rs.getString(2));
				mag.setMagPassword(rs.getString(3));
				list.add(mag);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return list;
	}

	@Override
	public int updateReader(Manager manager) {
		String sql = "update tbl_manager set magName=?,magPassword=? where magId=?";
		Object[] params = {manager.getMagName(),manager.getMagPassword(),manager.getMagId()};
		return super.executeUpdate(sql, params);
	}

	@Override
	public Manager queryManagerById(int magId) {
		String sql = "select * from tbl_manager where magId=?";
		Object[] params = {magId};
		try {
			rs = super.executeQuery(sql, params);
			if(rs.next()){
				Manager mag = new Manager();
				mag.setMagId(rs.getInt(1));
				mag.setMagName(rs.getString(2));
				mag.setMagPassword(rs.getString(3));
				return mag;
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			super.closeAll();
		}
		return null;
	}

}
