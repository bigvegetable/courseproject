package org.entity;

public class Manager {
	private int magId;
	private String magName;
	private String magPassword;
	
	public Manager(){}
	
	public Manager(int magId, String magName, String magPassword) {
		super();
		this.magId = magId;
		this.magName = magName;
		this.magPassword = magPassword;
	}

	public Manager(String magName, String magPassword) {
		super();
		this.magName = magName;
		this.magPassword = magPassword;
	}
	public int getMagId() {
		return magId;
	}
	public void setMagId(int magId) {
		this.magId = magId;
	}
	public String getMagName() {
		return magName;
	}
	public void setMagName(String magName) {
		this.magName = magName;
	}
	public String getMagPassword() {
		return magPassword;
	}
	public void setMagPassword(String magPassword) {
		this.magPassword = magPassword;
	}

}
